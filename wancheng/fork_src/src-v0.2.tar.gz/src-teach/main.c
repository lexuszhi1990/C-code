#include <stdio.h>
#include "main.h"
int main(void)
{
	info_t fb;
	init_fb(&fb);
	int i;
	
	for(i = 0; i < 100; ++i)
		fb_pixel(&fb, 512+i, 384, 0xFF0000);
	
	return 0;
}
