#include <stdio.h>
#include <stdlib.h>

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/fb.h>

#include "main.h"

/* framebuffer 编程 */
int init_fb(info_t *fb)
{
	/* step 1: open file */
	int fd = open("/dev/fb0", O_RDWR);
	if(fd < 0){
		perror("Error for open");
		exit(1);
	}
	printf("open fb0 Success\n");
	/* step 2: r/w file */
	struct fb_var_screeninfo fb_var;
	if(ioctl(fd, FBIOGET_VSCREENINFO,
		    &fb_var) < 0){
		perror("Error for ioctl");
		exit(1);
	}
	printf("w:%d\t h:%d\t bpp:%d\n",
		  fb_var.xres, fb_var.yres,
		  fb_var.bits_per_pixel);

	int w, h, bpp;
	w = fb_var.xres;
	h = fb_var.yres;
	bpp = fb_var.bits_per_pixel;
      
#include <sys/mman.h>
	int *fb_mem = mmap(NULL,
				    w * h * bpp/8, PROT_READ|PROT_WRITE,
				    MAP_SHARED, fd, 0);
	if(fb_mem == MAP_FAILED){
		perror("Error for mmap");
		exit(1);
	}

	fb->w = w;
	fb->h = h;
	fb->bpp = bpp;
	fb->fb_mem = fb_mem;
	
//	*fb_mem = 0x00FF0000;
	/* step 3: close file */
	close(fd);
	  
	return 0;
}
int fb_pixel(info_t *fb, int x, int y,  u32_t color)
{
	u32_t *p = fb->fb_mem;
	*(p + x + y * fb->w)	= color;
	
	return 0;
}
