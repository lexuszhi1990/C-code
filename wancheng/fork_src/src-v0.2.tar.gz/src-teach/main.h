#ifndef __MAIN_H__
#define __MAIN_H__
typedef unsigned int u32_t;
typedef unsigned short u16_t;
typedef unsigned char u8_t;
typedef struct 
{
	int w;
	int h;
	int bpp;
	void *fb_mem;
}info_t;

extern int init_fb(info_t *fb);

extern int fb_pixel(info_t *fb, int x, int y,
		   u32_t color);



#endif
